import java.util.*;

public class OptionalClassExample1
{
    public static void main(String args[])
    {
    	String str[] = new String[10];
    	
    	String test = str[5].toLowerCase();
    	
    	System.out.println("Checking Optional Class : "+test);
    }

}