package com.springboot.quick.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseApi {

	public static void main(String[] args) {
	   //static class	
       SpringApplication.run(CourseApi.class, args);
		
	}
}
	