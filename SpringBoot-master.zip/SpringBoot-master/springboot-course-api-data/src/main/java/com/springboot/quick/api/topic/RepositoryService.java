package com.springboot.quick.api.topic;

import org.springframework.data.repository.CrudRepository;

public interface RepositoryService extends CrudRepository<Topic, String> {


}
